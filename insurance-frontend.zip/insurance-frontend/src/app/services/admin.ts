import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseUrl = 'https://insurance-policy-system-dfd5hsd7ambxh3bs.centralus-01.azurewebsites.net/api/admin';

  constructor(private http: HttpClient) {}

  // ✅ GET ALL POLICIES
  getAllPolicies(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/policies`);
  }

  // ✅ CREATE POLICY
  createPolicy(payload: any): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/policies`, payload, {
      responseType: 'text' as 'json'
    });
  }

  // ✅ SEARCH POLICIES
  searchPolicies(keyword: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/policies/search?keyword=${keyword}`);
  }

  // ✅ DELETE POLICY
  deletePolicy(id: number): Observable<string> {
    return this.http.delete<string>(`${this.baseUrl}/policies/${id}`, {
      responseType: 'text' as 'json'
    });
  }

  // ✅ GET PENDING REQUESTS
  getPendingRequests(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/pending-requests`);
  }

  // ✅ APPROVE / REJECT POLICY
  approvePolicyRequest(dto: any): Observable<string> {
    return this.http.post<string>(`${this.baseUrl}/approve`, dto, {
      responseType: 'text' as 'json'
    });
  }

  // ✅ GET ALL CUSTOMERS
  getAllCustomers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/customers`);
  }
}
