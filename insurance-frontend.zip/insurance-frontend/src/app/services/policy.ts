import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  private baseUrl = 'https://insurance-policy-system-dfd5hsd7ambxh3bs.centralus-01.azurewebsites.net/api/admin/policies';

  constructor(private http: HttpClient) {}

  getAllPolicies(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  createPolicy(payload: any): Observable<string> {
    return this.http.post<string>(this.baseUrl, payload);
  }

  searchPolicies(keyword: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/search?keyword=${keyword}`);
  }

  deletePolicy(id: number): Observable<string> {
    return this.http.delete<string>(`${this.baseUrl}/${id}`);
  }
}
