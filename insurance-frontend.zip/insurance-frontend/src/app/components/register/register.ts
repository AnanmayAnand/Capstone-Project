import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class RegisterComponent {

  user = {
    name: '',
    email: '',
    phone: '',
    username: '',
    password: '',
    dob: '',
    address: ''
  };

  loading = false;
  message = '';
  error = '';

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  register() {
    this.loading = true;
    this.message = '';
    this.error = '';

    // Log the payload being sent
    console.log('Sending registration data:', this.user);

    this.http
      .post('https://insurance-policy-system-dfd5hsd7ambxh3bs.centralus-01.azurewebsites.net/api/auth/register', this.user)
      .subscribe({
        next: () => {
          this.loading = false;
          this.message = '✅ Account created successfully! Redirecting to login...';

          // ⏳ small delay → better UX
          setTimeout(() => {
            this.router.navigate(['/']);
          }, 1500);
        },
        error: (err) => {
          this.loading = false;

          // Log full error for debugging
          console.error('Registration error:', err);
          console.error('Error response:', err.error);

          if (err.status === 409) {
            this.error = '❌ Username or email already exists';
          } else if (err.status === 400) {
            this.error = `❌ Validation error: ${err.error?.message || 'Invalid input data'}`;
          } else {
            this.error = '❌ Registration failed. Please try again.';
          }
        }
      });
  }
}
