import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,   // 🔥 REQUIRED for *ngIf
    FormsModule
  ],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {

  username = '';
  password = '';
  errorMessage = '';
  loading = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  login() {
    this.loading = true;
    this.errorMessage = '';

    this.authService.login(this.username, this.password)
      .subscribe({
        next: (role: string) => {
          this.loading = false;

          localStorage.setItem('username', this.username);
          localStorage.setItem('role', role);

          if (role === 'ADMIN') {
            this.router.navigateByUrl('/admin');
          } else if (role === 'CUSTOMER') {
            this.router.navigateByUrl('/customer');
          } else {
            this.errorMessage = 'Invalid role';
          }
        },
        error: () => {
          this.loading = false;
          this.errorMessage = 'Invalid username or password';
        }
      });
  }

  goToRegister() {
    this.router.navigateByUrl('/register');
  }
}
