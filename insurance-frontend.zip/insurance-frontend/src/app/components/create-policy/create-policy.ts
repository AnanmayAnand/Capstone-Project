import { Component, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../../services/admin';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-create-policy',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './create-policy.html',
  styleUrl: './create-policy.css'
})
export class CreatePolicyComponent implements OnDestroy {

  policyName = '';
  policyType = 'HEALTH';
  premium = 0;
  durationYears = 0;
  description = '';        // ✅ NEW

  message = '';
  success = false;
  loading = false;

  private destroy$ = new Subject<void>();

  constructor(
    private adminService: AdminService,
    private router: Router
  ) {}

  createPolicy() {
    // ✅ VALIDATE BEFORE SENDING
    if (!this.policyName.trim()) {
      this.message = '❌ Policy name is required';
      return;
    }
    if (this.premium <= 0) {
      this.message = '❌ Premium amount must be greater than 0';
      return;
    }
    if (this.durationYears <= 0) {
      this.message = '❌ Duration must be greater than 0 years';
      return;
    }

    this.loading = true;
    this.message = '';
    this.success = false;

    const payload = {
      policyName: this.policyName,
      policyType: this.policyType,
      premiumAmount: this.premium,
      duration: this.durationYears,
      description: this.description      // ✅ SEND TO BACKEND
    };

    this.adminService.createPolicy(payload)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
      next: () => {
        this.loading = false;
        this.success = true;

        // ✅ Show message clearly
        this.message = '✅ Policy created successfully. Redirecting...';

        // 🔥 Give user time to SEE it
        setTimeout(() => {
          this.router.navigate(['/admin/policies']);
        }, 2000); // ⬅️ 2 seconds (perfect)
      },
      error: (err) => {
        console.error('CREATE POLICY ERROR:', err);
        console.error('Status:', err.status);
        console.error('Message:', err.message);
        console.error('Error Body:', err.error);
        this.loading = false;
        this.success = false;
        this.message = err.error?.message || '❌ Error creating policy. Check console for details.';
      }
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
