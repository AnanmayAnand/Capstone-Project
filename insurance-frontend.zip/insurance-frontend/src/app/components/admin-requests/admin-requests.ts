import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../services/admin';

@Component({
  selector: 'app-admin-requests',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-requests.html',
  styleUrl: './admin-requests.css'
})
export class AdminRequestsComponent implements OnInit {

  requests: any[] = [];
  loading: boolean = false;   // ✅ FIX
  error: string = '';         // ✅ FIX
  message: string = '';       // already used
  processing: boolean = false; // Track if we're processing an action

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.loadRequests();
  }

  loadRequests() {
    this.loading = true;
    this.error = '';

    this.adminService.getPendingRequests().subscribe({
      next: (data) => {
        this.requests = data;
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load requests';
        this.loading = false;
      }
    });
  }

  approve(id: number) {
    this.updateStatus(id, 'APPROVED');
  }

  reject(id: number) {
    this.updateStatus(id, 'REJECTED');
  }

  updateStatus(customerPolicyId: number, status: string) {
    if (this.processing) return; // Prevent duplicate requests

    this.processing = true;
    this.message = '';

    // Try different field name formats the backend might expect
    const payload = {
      id: customerPolicyId,  // Backend likely expects 'id' not 'customerPolicyId'
      status
    };

    console.log('Sending approval request with ID:', customerPolicyId, 'Status:', status);
    console.log('Payload:', JSON.stringify(payload, null, 2));

    this.adminService.approvePolicyRequest(payload).subscribe({
      next: (response) => {
        console.log('Approval response:', response);
        this.message = `✅ Policy ${status.toLowerCase()} successfully`;
        this.processing = false;
        setTimeout(() => this.loadRequests(), 1500);
      },
      error: (err) => {
        console.error('Approval error:', err);
        console.error('Full error object:', JSON.stringify({
          status: err.status,
          statusText: err.statusText,
          message: err.message,
          errorBody: err.error,
          url: err.url
        }, null, 2));
        this.message = `❌ Action failed: ${err.error?.message || err.message}`;
        this.processing = false;
      }
    });
  }
}
