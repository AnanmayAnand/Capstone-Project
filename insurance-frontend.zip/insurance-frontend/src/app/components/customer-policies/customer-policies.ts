import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../services/customer';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-customer-policies',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './customer-policies.html',
  styleUrl: './customer-policies.css'
})
export class CustomerPoliciesComponent implements OnInit, OnDestroy {

  @Input() view!: 'ALL' | 'REQUESTED' | 'MY';

  policies: any[] = [];
  myPolicies: any[] = [];
  username = localStorage.getItem('username');
  message = '';
  loading = false;

  isAdmin = false; // ✅ USED IN UI

  private destroy$ = new Subject<void>();

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    this.loadPolicies();
  }

  loadPolicies() {
    this.loading = true;
    this.message = '';

    // 🔹 All policies
    this.customerService
      .getAllPolicies()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (d) => (this.policies = d),
        error: (err) => {
          console.error('Failed to load policies:', err);
          this.message = 'Failed to load policies';
        }
      });

    // 🔹 My applied policies
    if (this.username) {
      this.customerService
        .getMyPolicies(this.username)
        .pipe(takeUntil(this.destroy$))
        .subscribe({
          next: (d) => {
            this.myPolicies = d;
            this.loading = false;
          },
          error: (err) => {
            console.error('Failed to load my policies:', err);
            this.loading = false;
            this.message = 'Failed to load your policies';
          }
        });
    }
  }

  alreadyApplied(policyId: number): boolean {
    return this.myPolicies.some(mp => mp.policy.policyId === policyId);
  }

  applyPolicy(policyId: number) {
    if (!this.username) {
      this.message = '❌ Username not found. Please login again.';
      return;
    }

    this.message = '';
    console.log('Applying for policy:', { username: this.username, policyId });

    this.customerService
      .applyPolicy(this.username, policyId)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response) => {
          console.log('Policy application response:', response);
          this.message = '✅ Policy applied successfully!';
          setTimeout(() => this.loadPolicies(), 1500);
        },
        error: (err) => {
          console.error('Policy application error:', err);
          console.error('Status:', err.status);
          console.error('Error body:', err.error);
          this.message = `❌ Error: ${err.error?.message || err.message || 'Failed to apply policy'}`;
        }
      });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}

