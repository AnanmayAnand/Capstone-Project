import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../services/admin';

@Component({
  selector: 'app-admin-policies',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-policies.html',
  styleUrl: './admin-policies.css'
})
export class AdminPoliciesComponent implements OnInit {

  allPolicies: any[] = [];   // ✅ MASTER LIST
  policies: any[] = [];      // ✅ DISPLAY LIST

  loading = true;
  error = '';
  successMessage = '';

  searchText = '';

  constructor(
    private adminService: AdminService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {

    // success message after create
    this.route.queryParams.subscribe(params => {
      if (params['created']) {
        this.successMessage = '✅ Policy created successfully';
        setTimeout(() => this.successMessage = '', 3000);
      }
    });

    this.loadPolicies();
  }

  loadPolicies() {
    this.loading = true;

    this.adminService.getAllPolicies().subscribe({
      next: (data) => {
        this.allPolicies = data;   // ✅ KEEP ORIGINAL
        this.policies = data;      // ✅ SHOW IMMEDIATELY
        this.loading = false;
      },
      error: () => {
        this.error = 'Failed to load policies';
        this.loading = false;
      }
    });
  }

  // 🔍 FRONTEND SEARCH (name + type)
  searchPolicies() {
    const value = this.searchText.toLowerCase().trim();

    if (!value) {
      this.policies = this.allPolicies; // reset
      return;
    }

    this.policies = this.allPolicies.filter(p =>
      p.policyName.toLowerCase().includes(value) ||
      (p.policyType && p.policyType.toLowerCase().includes(value))
    );
  }
}
