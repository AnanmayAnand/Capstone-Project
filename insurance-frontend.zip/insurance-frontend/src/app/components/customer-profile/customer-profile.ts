import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerService } from '../../services/customer';

@Component({
  selector: 'app-customer-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './customer-profile.html',
  styleUrl: './customer-profile.css'
})
export class CustomerProfileComponent implements OnInit {

  customer: any = null;
  error = '';
  loading = true;

  constructor(private customerService: CustomerService) {}

  ngOnInit(): void {
    console.log('Profile component initialized');

    const username = localStorage.getItem('username');
    console.log('Username from storage:', username);

    if (!username) {
      this.error = 'User not logged in';
      this.loading = false;
      return;
    }

    this.customerService.getProfile(username).subscribe({
      next: (data) => {
        console.log('API SUCCESS:', data);
        this.customer = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('API FAILED:', err);
        this.error = 'Failed to load profile';
        this.loading = false;
      }
    });
  }
}
